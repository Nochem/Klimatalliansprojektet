$(document).ready(function(){
    
	window.onbeforeunload = function(){
		return "";
	};

});
