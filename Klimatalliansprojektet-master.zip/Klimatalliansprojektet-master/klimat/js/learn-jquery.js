//$ is the same as writing jQuery
$(document).ready(function(){
	//BASIC SELECTORS
	//Detta väljer alla paragrafer på webbsidan och ger
	//dem en 4 pixlar tjock kant
	
	//Det är helt enkelt taggen på insidan av parantesen som säger
	//som påverkas av
});
